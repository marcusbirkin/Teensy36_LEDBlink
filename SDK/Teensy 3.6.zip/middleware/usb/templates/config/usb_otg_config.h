/*
 * Copyright (c) 2015 - 2016, Freescale Semiconductor, Inc.
 * Copyright 2016 - 2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#define USB_OTG_CONFIG_KHCI 1
#define USB_OTG_KHCI_PERIPHERAL_ENABLE 1
